// Garrick Morley
// ISYS 221-001
// Assignment #3 - Lights Out Code Explanation
// Due: 01/03/2021

package com.zybooks.lightsout;
//  This class is used to pass data between activities and save the state using key value
//  pairs (dictionary)

import java.util.Random;
// This imports the random function that allows us to generate random numbers

public class LightsOutGame {
// This creates the class called "LightsOutGame"
    public static final int GRID_SIZE = 3;
    // This creates a public static final integer called "GRID_SIZE" and sets it to "3"

    // Lights that make up the grid
    private final boolean[][] mLightsGrid;
    // This boolean value will be true or false depending on whether or not the light is on

    public LightsOutGame() {
        mLightsGrid = new boolean[GRID_SIZE][GRID_SIZE];
    }
    // This creates an object using the "LightsOutGame()" class that was created above

    public void newGame() {
    // This created a function called "newGame" which is void and takes no parameters
        Random randomNumGenerator = new Random();
        // This used the random import from above the create a random number
        for (int row = 0; row < GRID_SIZE; row++) {
        // This creates a for loop that lets us check each row found in the game
            for (int col = 0; col < GRID_SIZE; col++) {
            // This creates a for loop to let us check each column in each row since it is a
            // nested for loop, this way all 9 tiles are covered
                mLightsGrid[row][col] = randomNumGenerator.nextBoolean();
                // This decides whether the tile will start as "on" or "off" when the function
                // "newGame" is called, and due to the for loops this is done on each tile
            }
        }
    }

    public boolean isLightOn(int row, int col) {
        return mLightsGrid[row][col];
    }
    // This creates a simple function that returns a boolean true or false for if the light is on

    public void selectLight(int row, int col) {
    // This creates a new function called "selectLight" which is void and takes 2 parameters
        mLightsGrid[row][col] = !mLightsGrid[row][col];
        // This if statement ensures that "mLightsGrid" is not equal to itself to start with
        if (row > 0) {
        // This if statement checks to see if the row is higher than 0
            mLightsGrid[row - 1][col] = !mLightsGrid[row - 1][col];
            // If it is, then this statement gets enacted which sets this row to 0 (turns it off)
        }
        if (row < GRID_SIZE - 1) {
        // This if statement checks to see if the row is less than the variable "GRID_SIZE" - 1
            mLightsGrid[row + 1][col] = !mLightsGrid[row + 1][col];
            // If it is, then this statement gets enacted which sets this row to 1 (turns it on)
        }
        if (col > 0) {
        // This if statement checks to see if the column is higher than 0
            mLightsGrid[row][col - 1] = !mLightsGrid[row][col - 1];
            // If it is, then this statement gets enacted which sets this column to 0 (turns it off)
        }
        if (col < GRID_SIZE - 1) {
        // This if statement checks to see if the column is less than the variable "GRID_SIZE" - 1
            mLightsGrid[row][col + 1] = !mLightsGrid[row][col + 1];
            // If it is, then this statement gets enacted which sets this column to 1 (turns it on)
        }
    }

    public boolean isGameOver() {
    // This creates a boolean function called "isGameOver" that decides if the game is over or not
        for (int row = 0; row < GRID_SIZE; row++) {
        // This  creates a for loop to check each row
            for (int col = 0; col < GRID_SIZE; col++) {
            // This  creates a for loop to check each column in each row
                if (mLightsGrid[row][col]) {
                // This if statement checks if any of the lights are on from the above loops
                    return false;
                    // So if not all of the lights are off, it returns false and the game continues
                    // by returning the "false" value
                }
            }
        }
        return true;
        // But if all of the lights are on then the function returns "true" and the game should end
        // which is made known by returning the "true" value
    }

        public String getState() {
        // This creates a public string function that gets the current state of the light
            StringBuilder boardString = new StringBuilder();
            // This creates a new object called "boardString" using the "StringBuilder()" function
            for (int row = 0; row < GRID_SIZE; row++) {
            // This creates a for loop that checks each row like the ones above
                for (int col = 0; col < GRID_SIZE; col++) {
                // This creates a for loop that checks each column in each row again
                    char value = mLightsGrid[row][col] ? 'T' : 'F';
                    // This creates a character value and sets it to "T" or "F" based on the
                    // results of the grid loops above
                    boardString.append(value);
                    // This uses the "boardString()" function and appends the character value that
                    // was just created above to it, and once again due to the for loop setup
                    // above, this will be done for each of the 9 tiles
                }
            }

            return boardString.toString();
            // This returns the "boardString()" value from above, but as a string by using the
            // "toString()" function to modify it
        }

        public void setState(String gameState) {
        // This creates a public void function called "setState" which takes in 1 parameter
            int index = 0;
            // This creates an integer variable and sets it to zero
            for (int row = 0; row < GRID_SIZE; row++) {
            // This creates a for loop like the ones above and checks each row
                for (int col = 0; col < GRID_SIZE; col++) {
                // This creates another for loop like ones above and checks each column of each row
                    mLightsGrid[row][col] = gameState.charAt(index) == 'T';
                    // This sets the specific tile to have a "T" by using the "charAt()" function
                    // on the gameState parameter that was given to the function
                    index++;
                    // This increments the index by one each iteration, so 9 times in total
                }
            }
        }
    }
