// Garrick Morley
// ISYS 221-001
// Assignment #3 - Lights Out Code Explanation
// Due: 10/03/2021

package com.zybooks.lightsout;
//  This class is used to pass data between activities and save the state using key value
//  pairs (dictionary)

// This first part of the imports uses the regular android package

import android.app.Activity;
// This imports the "Activity" class from the "app" package, which is an application component which
// provides the users with a screen that can be interacted with. This is one of android's 4 core
// application components, with the other of these two being Service. The other two that can be
// picked between are from the .content package, namely "BroadcastReceiver" and "ContentProvider"
import android.content.Intent;
// This imports the "Intent" class from the content package, which is used for delivering structured
// messages between different application components. This is another one of the 4 core components
import android.os.Bundle;
// This this imports the "Bundle" class from the android operating system which provides basic
// system services, message passing, and inter-process communication on the device
import android.util.Log;
// This imports the "Log" class from the utility package, which is used for an API for sending log
// output
import android.view.View;
// This imports the "View" class from the view package, which represents the basic building block
// for user interface components
import android.widget.Button;
// This imports the "Button" class from the widget package, which is used to create a user interface
// element that the user can tap or click to perform an action
import android.widget.GridLayout;
// This imports the "GridLayout" class from the widget package, which is used to create a layout
// that places its children in a rectangular grid
import android.widget.Toast;
// This imports the "Toast" class from the widget package, which creates a quick little message for
// the user, the "Toast" class helps you create and show those


// This second part of the imports uses the backward compatible androidx package

import androidx.activity.result.ActivityResult;
// This imports the "ActivityResult" class from the androidx result package, which creates a
// container for an activity result as obtained from "onActivityResult"
import androidx.activity.result.ActivityResultCallback;
// This imports the "ActivityResultCallback" class from the androidx result package, which is a
// type-safe callback to be called when an "activity result" is available
import androidx.activity.result.ActivityResultLauncher;
// This imports the "ActivityResultLauncher" class from the androidx result package, which is a
// launcher for a previously-prepared call to start the process of executing an "ActivityResultContract"
import androidx.activity.result.contract.ActivityResultContracts;
// This imports the "ActivityResultContracts" class from the androidx result package, which is a
// collection of some standard activity call contracts, as provided by android
import androidx.annotation.NonNull;
// This imports the "NonNull" class from the androidx annotation package, which denotes that a
// parameter,field, or method return value can never be null
import androidx.appcompat.app.AppCompatActivity;
// This imports the "AppCompatActivity" class from the androidx appcompat package, which is a base
// class for activities that wish to use some of the newer platform features on older devices
import androidx.core.content.ContextCompat;
// This imports the "ContextCompat" class from the androidx content package, which is a helper for
// accessing features in "Context"

public class MainActivity extends AppCompatActivity {
// This creates the main class to be run in the MainActivity.java file, and also utilizes the
// "AppCompatActivity" features through "extends"

    private final String GAME_STATE = "gameState";
    // This creates a private final string variable called "GAME_STATE" and is holding the string
    // "gameState"

    private LightsOutGame mGame;
    // This creates the private variable "mGame" using the "LightsOutGame" class
    private GridLayout mLightGrid;
    // This creates the private variable "mLightGrid" using the "GridLayout" class
    private int mLightOnColor;
    // This creates the private int "mLightOnColor"
    private int mLightOffColor;
    // This creates the private int "mLightOffColor"

    @Override
    // The @Override annotation informs the compiler that the element is meant to override an
    // element declared in a superclass
    protected void onCreate(Bundle savedInstanceState) {
    // This uses a protected void class called onCreate which is used to launch the activity
    // when called on, which happens when the application is started or the orientation changed
        super.onCreate(savedInstanceState);
        // This tells the virtual machine to run our code in addition to the existing code in the
        // onCreate() of the parent class; Without it only our code would run
        setContentView(R.layout.activity_main);
        // This calls the method "setContentView" to set the xml file that we want as our main
        // layout when the app starts

        mLightGrid = findViewById(R.id.light_grid);
        // This calls the method "findViewById()" and sets mLightGrid to that ID from the xml file

        mLightOnColor = ContextCompat.getColor(this, R.color.yellow);
        // This uses the "ContextCompat" import to get the color from the xml file and set it to
        // the variable "mLightOnColor"
        mLightOffColor = ContextCompat.getColor(this, R.color.black);
        // This uses the "ContextCompat" import to get the color from the xml file and set it to
        // the variable "mLightOffColor"

        mGame = new LightsOutGame();
        // This creates a new object using the LightsOutGame class
        if (savedInstanceState == null) {
        // This checks to see if the saved state is null
            startGame();
            // If the saved state is null then a new game is started using the "startGame" function
        }
        else {
        // If the saved state is not null that means that there is a game in progress
            String gameState = savedInstanceState.getString(GAME_STATE);
            // Since there is already a saved state, this creates a new string variable called
            // "gameState" and sets it to the already existing string "GAME_STATE" using the
            // function "getString()"
            mGame.setState(gameState);
            // This sets the variable "mGame" to the value of "gameState" using the function
            // "setState()"
            setButtonColors();
            // This calls the function "setButtonColors()"
            Log.d("GameState", gameState);
            // This creates a tag for "gameState" using the "Log" import from above
        }
    }
    @Override
    // The @Override annotation informs the compiler that the element is meant to override an
    // element declared in a superclass
    protected void onSaveInstanceState(@NonNull Bundle outState) {
    // This uses the protected void class "onSaveInstanceState()" and the "Bundle" import from
    // above to retrieve the saved state of the game
        super.onSaveInstanceState(outState);
        // This once again tells the Java Virtual Machine to run our code in addition to the
        // existing code like we did above
        outState.putString(GAME_STATE, mGame.getState());
        // This uses the function "putString()" to put the string from "GAME_STATE" into "outState"
        setButtonColors();
        // This once again calls the function "setButtonColors()" to set the button colors

    }

    private void startGame() {
    // This creates the private void function "startGame()" which does not take in any parameters
        mGame.newGame();
        // This uses the value of "mGame" in the function "newGame()"
        setButtonColors();
        // This once again calls the function "setButtonColors()" to set the button colors
    }

    public void onLightButtonClick(View view) {
    // This creates a public void function that is activated when a button is clicked and uses the
    // "View" import from above

        // Find the button's row and col
        int buttonIndex = mLightGrid.indexOfChild(view);
        // This creates and sets the integer variable to mLightGrid
        int row = buttonIndex / LightsOutGame.GRID_SIZE;
        // This finds the row of the button by dividing the buttonIndex by the GRID_SIZE
        int col = buttonIndex % LightsOutGame.GRID_SIZE;
        // This finds the column of the button by getting the remainder (modulo) of the buttonIndex
        //divided by the GRID_SIZE

        mGame.selectLight(row, col);
        // This uses the "selectLight" function to select the button based on the row and column
        setButtonColors();
        // This once again calls the function "setButtonColors()" to set the button colors

        // Congratulate the user if the game is over
        if (mGame.isGameOver()) {
        // This if statement activates if the "GameOver()" function returns true
            Toast.makeText(this, R.string.congrats, Toast.LENGTH_SHORT).show();
            // If that does happen, this will output "Congratulations!" to the user
        }
    }

    private void setButtonColors() {
    // This creates a private void function called "setButtonColors()" which will be used to set
    // the colors of the 9 buttons (I've also called them tiles before)

        // Set all buttons' background color
        for (int row = 0; row < LightsOutGame.GRID_SIZE; row++) {
        // This for loop goes through all of the rows until it reaches LightsOutGame.GRID_SIZE
            for (int col = 0; col < LightsOutGame.GRID_SIZE; col++) {
            // This nested for loop goes through all of the columns until it reaches
            // LightsOutGame.GRID_SIZE, this effectively hits all 9 button locations


                // Find the button in the grid layout at this row and col
                int buttonIndex = row * LightsOutGame.GRID_SIZE + col;
                // This creates and sets the buttonIndex variable to the amount of rows times the
                // value of "LightsOutGame.GRID_SIZE" plus the number of columns
                Button gridButton = (Button) mLightGrid.getChildAt(buttonIndex);
                // This creates a new object called "gridButton" by using the "getChildAt()"
                // function on the "buttonIndex"

                if (mGame.isLightOn(row, col)) {
                // This if statement activates if the light is on in the button
                    gridButton.setBackgroundColor(mLightOnColor);
                    // If the light is off turn it on
                } else {
                  // If the light was not on then this happens
                    gridButton.setBackgroundColor(mLightOffColor);
                    // If the light is on turn it off
                }
            }
        }
    }

    public void onNewGameClick(View view) {
        startGame();
    }
    // This creates a public void function that activates the "startGame()" function when the
    // "onNewGameClick" is activated using the view import from above


    public void onHelpClick(View view) {
    // This creates a public void function that opens up a help menu when clicked, also using the
    // view import from before
        Intent intent = new Intent(this, HelpActivity.class);
        // This creates a new object called "intent" to be used for the "HelpActivity" class
        startActivity(intent);
        // This used the "startActivity()" function on the new object "intent"
    }

    public void onChangeColorClick(View view) {
    // This creates a public void function that changes color on click using the view import
        Intent intent = new Intent(this, ColorActivity.class);
        // This creates a new object called "intent" to be used for the "ColorActivity" class
        mColorResultLauncher.launch(intent);
        // This uses the "launch()" function to launch the colors from "mColorResultLauncher"
    }

    ActivityResultLauncher<Intent> mColorResultLauncher = registerForActivityResult(
    // This uses the "ActivityResultLauncher" import on the object "Intent" to launch the colors
            new ActivityResultContracts.StartActivityForResult(),
            // This creates a new object called "ActivityResultContracts" using the
            // "StartActivityForResult()" function
            new ActivityResultCallback<ActivityResult>() {
            // This creates a new object called "ActivityResultCallback" by using the
            // "ActivityResult" import from before
                @Override
                // The @Override annotation informs the compiler that the element is meant to
                // override an element declared in a superclass
                public void onActivityResult(ActivityResult result) {
                    // This creates a new function called "onActivityResult" which takes the two
                    // parameters "ActivityResult" and "result"
                    if (result.getResultCode() == Activity.RESULT_OK) {
                    // This if statement activates if the result of the function "getResultCode()"
                    // is equal to "Activity.RESULT_OK"
                        Intent data = result.getData();
                        // This creates another new object from "Intent" called "data" which is
                        // then set to the result of "result.getData()"
                        if (data != null) {
                        // This nested if statement activates if the data object that was just
                        // created is not equal to null, which I think is ensured by the androidx
                        // import: androidx.annotation.NonNull;
                            int colorId = data.getIntExtra(ColorActivity.EXTRA_COLOR, R.color.yellow);
                            // This creates an integer variable called "colorId" which is then set
                            // to the color yellow by using the "ColorActivity" method and the
                            // R.color.yellow argument
                            mLightOnColor = ContextCompat.getColor(MainActivity.this, colorId);
                            // This sets the variable "mLightOnColor" to the the resulting color
                            // from using the "getColor()" method on the object "ContextCompat",
                            // using the "androidx.core.content.ContextCompat;" import from above
                            setButtonColors();
                            // This once again calls the function "setButtonColors()" to set the button colors
                        }
                    }
                }
            });

}